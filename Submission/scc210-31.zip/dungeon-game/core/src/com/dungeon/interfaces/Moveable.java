package com.dungeon.interfaces;

public interface Moveable {
    /**
     * Move the entity.
     */
    public void move();
}
