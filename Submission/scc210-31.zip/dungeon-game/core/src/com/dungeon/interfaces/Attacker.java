package com.dungeon.interfaces;

public interface Attacker{
    /**
     * Checks if attacker entity should attack.
     * If yes, do an attack.
     */
    public void attack();
}